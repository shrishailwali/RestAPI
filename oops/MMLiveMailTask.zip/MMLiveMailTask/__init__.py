from MMLiveMailTask.semdmail import SendEmail
from MMLiveMailTask.task import mail_receiver