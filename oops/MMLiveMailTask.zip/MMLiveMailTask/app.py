from MMLiveMailTask.task import mail_receiver

if __name__ =='__main__':
    mail_receiver()